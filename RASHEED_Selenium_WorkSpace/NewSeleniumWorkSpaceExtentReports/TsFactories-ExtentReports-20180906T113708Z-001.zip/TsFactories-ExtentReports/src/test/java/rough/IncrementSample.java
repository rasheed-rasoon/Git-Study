package rough;

public class IncrementSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		int i=0;
		i++;
		System.out.println(i+" First time");
++i;

}
