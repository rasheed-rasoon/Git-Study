package com.cgg.constants;

public class AmendmentAndLicenceWebTableProcessConstants {
	public static final String SENDAPPLICATIONUMBER="input[type='search']";
	public static final String CLICKONPROCESS=".//*[@id='detailsTable']/tbody/tr/td[9]/button";
	
}
