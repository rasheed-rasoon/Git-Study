package com.cgg.constants;

public class AmendmentOfLicenceDistrictWebTablePageConstants {
	public static final String CLICKONPRESCRYTINYPENDINGTOTAL=".//*[@id='detailsTable']/tbody/tr[6]/td[4]/a";
	public static final String CLICKONAWAITINGQUERYRESPONSE=".//*[@id='detailsTable']/tbody/tr[6]/td[5]/a";
	public static final String CLICKONAPPROVALUNDERPROCESSTOTAL=".//*[@id='detailsTable']/tbody/tr[6]/td[6]/a";

}
