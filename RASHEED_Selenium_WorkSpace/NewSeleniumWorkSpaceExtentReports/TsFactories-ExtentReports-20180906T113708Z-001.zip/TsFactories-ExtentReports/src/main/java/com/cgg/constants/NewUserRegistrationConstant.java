package com.cgg.constants;

public class NewUserRegistrationConstant {
	public static final String NAME=".//*[@id='username']";
	public static final String DISTRICT=".//*[@id='fac_district']"; 
	public static final String MANDAL=".//*[@id='fac_mandal']";
	public static final String MOBILENUMBER=".//*[@id='mobile']";
	public static final String EMAILID=".//*[@id='emailid']";
	public static final String LOGINID=".//*[@id='loginid']";
	public static final String PASSWORD=".//*[@id='password']";
	public static final String CONFIRMPASSWORD=".//*[@id='password_cnf']";
	public static final String REGISTERBUTTON=".//*[@id='reg']";

}
