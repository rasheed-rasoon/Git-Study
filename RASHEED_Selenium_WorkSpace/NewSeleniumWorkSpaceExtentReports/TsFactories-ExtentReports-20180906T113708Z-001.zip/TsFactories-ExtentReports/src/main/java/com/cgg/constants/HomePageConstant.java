package com.cgg.constants;

public class HomePageConstant {
	
	
	public static final String REGESTEREDUSERLOGIN=".//*[@id='login_type_div1']/a[2]";  // ref variable should be caps
	public static final String NEWUSERREGISTRATION=".//*[@id='login_type_div1']/a[1]"; 
	
	public static final String INSPECTION=".//*[@id='lnk1']";


}
