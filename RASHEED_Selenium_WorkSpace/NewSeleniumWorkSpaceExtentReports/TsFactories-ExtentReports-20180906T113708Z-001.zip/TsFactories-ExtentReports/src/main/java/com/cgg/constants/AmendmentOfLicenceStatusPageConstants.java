package com.cgg.constants;

public class AmendmentOfLicenceStatusPageConstants {
	public static final String SELECTSTATUS=".//*[@id='status']";
	public static final String SENDOFFICERREMARKS="textarea#remarks";
	public static final String CLICKONUPDATE="input[value='Update']";
}
