package com.cgg.constants;

public class OfficerLoggedInPageConstant {
	public static final String PLANOFAPPROVAlVIEW = "html/body/div[1]/div[2]/center/div[2]/div/div[2]/div/a/div/span[1]";
	public static final String DOOFFICERLOGOUT = "a#lnk3";
	public static final String CLICKREGANDLICENCEVIEW = "html/body/div[1]/div[2]/center/div[2]/div/div[3]/div/a/div/span[1]";
	public static final String CLICKONAMENDMENTVIEW = "html/body/div[1]/div[2]/center/div[2]/div/div[9]/div/a/div/span[1]";
	public static final String CLICKONTRANSFEROFLICENCEVIEW = "html/body/div[1]/div[2]/center/div[2]/div/div[6]/div/a/div/span[1]";
}
