package com.cgg.constants;

public class GrievanceHomePageConstants {
	public static final String CITIZENNAME="txtCitizenName";
	public static final String MOBNUM="txtMobileNumber";
	public static final String LOCALITY="txtLocality";
	public static final String AJAXSEARCH="AutoExtLocality_completionListElem";
	
	public static final String LANDMARK="txtLandMark";
	public static final String WARDNAME="txt_wardname";
	public static final String CIRCLE="txt_circle";
	public static final String CATEGORY="ddlCategory";
	public static final String SUBCATEGORY="ddlSubCategory";
	public static final String REDRESSALTO="txtRedressalTo";
	public static final String GRIEVANCEDESCRIPTION="txtGrievanceDescription";
	public static final String SUBMIT="btnSubmit";
	
}
