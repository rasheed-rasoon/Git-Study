package com.cgg.constants;

public class AmendmentOfLicenceReplyTOQueryPageConstatns {
	public static final String CLICKONADDCELL="input[value='add']";
	public static final String ENTERDOCUMENTTYPE=".//*[@id='1_docType']";
	public static final String BROWSEDOCUMENT=".//*[@id='1_file']";
	public static final String CLICKONDELCELL="input[onclick*=del]";
	public static final String ENTERREMARKS="textarea#remarks_user";
	public static final String CLICKONDECLARATION="input#declaration";
	public static final String CLICKONSUBMITAPPLICATION=".btn.btn-sm.btn-success";


}
