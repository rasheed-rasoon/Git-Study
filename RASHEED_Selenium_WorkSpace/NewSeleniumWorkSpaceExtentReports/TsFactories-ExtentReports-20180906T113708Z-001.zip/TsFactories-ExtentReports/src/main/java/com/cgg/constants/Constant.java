package com.cgg.constants;

public class Constant {


	//****************************-Application Under Test-****************************//
	public static String APPLICATION_UNDER_TEST="http://test.cgg.gov.in/tsboilers";

	//****************************Paths-****************************//
	public static String CONFIG_FILE_PATH=(System.getProperty("user.dir")+"//src//test//resources//config.properties");

	public static String XLS_FILE_PATH = (System.getProperty("user.dir")+"\\data//TestCases.xlsx");
	
	public static String EXTENT_REPORTS_PATH = (System.getProperty("user.dir")+"\\Reports\\");
	
	
	public static String UPLOAD_FILE_PATH = "D:\\Url's status.txt";
			//(System.getProperty("user.dir")+"//src//com//cgg//data//TestCases.xlsx");
	public static String UPLOAD_Anexure = (System.getProperty("user.dir")+"\\uploads\\Anexure.jpg");

	public static String UPLOAD_Erectorlicence = (System.getProperty("user.dir")+"\\uploads\\Erectorlicence.jpg");

	public static String UPLOAD_Form_V = (System.getProperty("user.dir")+"\\uploads\\Form_V.jpg");

	public static String UPLOAD_Form1 = (System.getProperty("user.dir")+"\\uploads\\Form1.jpg");

	public static String UPLOAD_FormCBB = (System.getProperty("user.dir")+"\\uploads\\FormCBB.jpg");

	public static String UPLOAD_RequiredDocuments = (System.getProperty("user.dir")+"\\uploads\\RequiredDocuments.jpg");
	
	public static String SCREENSHOT_PATH=(System.getProperty("user.dir")+"\\Screenshorts\\");

}
